<?php

namespace App\Notifications\oldPReq;

use App\Models\ProductionRequest;
use App\Support\Settings;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ProductionRequestCreated extends Notification
{
//    use Queueable;
    public function __construct(public ProductionRequest $request) {
//        $this->afterCommit();
    }

    public function via(object $notifiable): array
    {
        $channels = [];
        if (Settings::get('notify_in_app', 1)) $channels[] = 'database';
        if (Settings::get('notify_email', 0))  $channels[] = 'mail';
        return $channels;
    }

    protected function title(): string
    {
        return $this->request->request_type === 'direct'
            ? 'طلب تصنيع مباشر'
            : 'طلب تصنيع غير مباشر';
    }

    public function toMail(object $notifiable): MailMessage
    {
        $pr   = $this->request;
        $url  = \App\Filament\Resources\ProductionRequestResource::getUrl('view', ['record' => $pr->getKey()]);

        $mail = (new MailMessage)
            ->subject("تم إنشاء {$this->title()} #{$pr->id}")
            ->greeting('مرحبًا،')
            ->line("تم إنشاء {$this->title()} برقم #{$pr->id}.");

        if (!empty($pr->project_name ?? '')) {
            $mail->line('المشروع: ' . $pr->project_name);
        }

        return $mail->action('عرض الطلب', $url);
    }

    public function toDatabase(object $notifiable): array
    {
        $pr  = $this->request;
        $url = \App\Filament\Resources\ProductionRequestResource::getUrl('view', ['record' => $pr->getKey()]);

        return [
            'title'   => $this->title(),
            'body'    => "تم إنشاء طلب رقم #{$pr->id}.",
            'icon'    => 'heroicon-o-clipboard-document-list',
            'actions' => [
                ['label' => 'عرض الطلب', 'url' => $url, 'openUrlInNewTab' => false],
            ],
            'type'                  => 'production_request_created',
            'pr_id'                 => $pr->id,
            'project_name'          => $pr->project_name ?? null,
            'request_type'          => $pr->request_type,
            'url'                   => $url,
            'created_at'            => now()->toIso8601String(),
        ];
    }
}
